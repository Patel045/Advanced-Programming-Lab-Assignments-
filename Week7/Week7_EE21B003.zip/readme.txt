Instead of 1 juputer notebook I am submitting 3 Python Files namely:
part1.py 
part2a.py
part2b.py

Run those standalone files to get the required output.